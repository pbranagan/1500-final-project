from flask import Flask, request, jsonify, render_template, redirect, flash
import pymysql
import random  # Used to randomly assign an agent

# Initialize the Flask app
app = Flask(__name__)
app.secret_key = 'secret'

# Database configuration
DB_CONFIG = {
    'host': '127.1.0.1',
    'user': 'root',       # Replace with your MySQL username
    'password': 'password',   # Replace with your MySQL password
    'database': 'online-travel-agent'
}

# Create a database connection
def get_db_connection():
    return pymysql.connect(**DB_CONFIG)

@app.route('/')
def home():
    return render_template('index.html')
    
@app.route('/agents')
def agents():
    # Get a database connection
    connection = get_db_connection()
    try:
        with connection.cursor() as cursor:
            # Query the agent table
            cursor.execute("SELECT agent_id, name, email, phone FROM agent")
            # Fetch all rows from the table
            agents = cursor.fetchall()
    finally:
        connection.close()
    
    # Pass the agents data to the 'agents.html' template
    return render_template('agents.html', agents=agents)

@app.route('/packages', methods=['GET', 'POST'])
def packages():
    if request.method == 'POST':
        # Get form data
        destination = request.form.get('destination')
        tier = request.form.get('tier')
        duration = request.form.get('duration')
        insurance_id = request.form.get('insurance')  # Insurance ID from the dropdown

        # Combine inputs to match the package description format
        package_name = f"{destination.capitalize()} {duration}-Day {tier.capitalize()}"

        # Verify package exists in the database
        connection = get_db_connection()
        try:
            with connection.cursor() as cursor:
                cursor.execute(
                    "SELECT * FROM package WHERE destination = %s AND duration = %s",
                    (package_name, duration)
                )
                package = cursor.fetchone()

                # If insurance is not 'No Insurance Coverage', fetch insurance details
                if insurance_id != '111':
                    cursor.execute(
                        "SELECT * FROM insurance WHERE insurance_id = %s",
                        (insurance_id,)
                    )
                    insurance = cursor.fetchone()
                else:
                    insurance = None
        finally:
            connection.close()

        # If package exists, redirect to checkout
        if package:
            return redirect(f"/checkout?package_id={package[0]}&insurance_id={insurance_id}")
        else:
            # If package does not exist, show an error and redirect back to packages
            flash("The selected package does not exist. Please try again.", "error")
            return redirect('/packages')

    # Render the package selection form for GET requests
    return render_template('packages.html')



@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    package_id = request.args.get('package_id')
    insurance_id = request.args.get('insurance_id')

    # Verify package exists
    connection = get_db_connection()
    try:
        with connection.cursor() as cursor:
            # Fetch the selected package details
            cursor.execute(
                "SELECT package_id, destination, duration, price FROM package WHERE package_id = %s",
                (package_id,)
            )
            package = cursor.fetchone()

            # Fetch insurance details if applicable
            if insurance_id and insurance_id != '111':  # '111' is "No Insurance Coverage"
                cursor.execute(
                    "SELECT * FROM insurance WHERE insurance_id = %s",
                    (insurance_id,)
                )
                insurance = cursor.fetchone()
                insurance_price = insurance[2]  # Extract the price of the insurance
            else:
                insurance = None
                insurance_price = 0.00  # No insurance selected, so no extra cost

            # Calculate the total cost (package price + insurance price)
            total_price = float(package[3]) + float(insurance_price)
    finally:
        connection.close()

    if not package:
        # If the package ID is invalid, redirect to /packages
        flash("The package you selected does not exist.", "error")
        return redirect('/packages')

    # Handle POST request to save user details
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        credit_card = request.form.get('credit_card')

        if not name or not email or not phone or not credit_card:
            flash("All fields are required.", "error")
            return redirect(request.url)

        # Insert customer into the database
        connection = get_db_connection()
        try:
            with connection.cursor() as cursor:
                # Check for existing email, phone, or credit card
                cursor.execute(
                    "SELECT customer_id FROM customer WHERE email = %s OR phone = %s OR credit_card = %s",
                    (email, phone, credit_card)
                )
                existing_customer = cursor.fetchone()

                if existing_customer:
                    flash(
                        "A customer with the same email, phone, or credit card already exists. Please use different details.",
                        "error"
                    )
                    return redirect(request.url)

                # Generate a unique customer ID
                cursor.execute("SELECT MAX(customer_id) FROM customer")
                max_customer_id = cursor.fetchone()[0]
                new_customer_id = (max_customer_id or 1000) + 1

                # Randomly assign an agent
                cursor.execute("SELECT agent_id, name, email, phone FROM agent")
                agents = cursor.fetchall()
                assigned_agent = random.choice(agents)  # Randomly select an agent
                agent_id = assigned_agent[0]
                agent_name = assigned_agent[1]
                agent_email = assigned_agent[2]
                agent_phone = assigned_agent[3]

                # Insert the new customer
                cursor.execute(
                    """
                    INSERT INTO customer (customer_id, name, email, phone, credit_card, agent_id)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    """,
                    (new_customer_id, name, email, phone, credit_card, agent_id)
                )

                # Generate a unique reservation ID
                cursor.execute("SELECT MAX(reservation_id) FROM reservation")
                max_reservation_id = cursor.fetchone()[0]
                new_reservation_id = (max_reservation_id or 1000) + 1

                # Insert the new reservation
                cursor.execute(
                    """
                    INSERT INTO reservation (reservation_id, total_price, customerid, agentid, packageid)
                    VALUES (%s, %s, %s, %s, %s)
                    """,
                    (new_reservation_id, total_price, new_customer_id, agent_id, package_id)
                )

                # Commit the transaction
                connection.commit()

                # Success message
                flash(f"Booking completed! Your agent is {agent_name}. Your reservation ID is {new_reservation_id}.", "success")
        except Exception as e:
            flash("An unexpected error occurred while processing your booking.", "error")
            print(f"Error: {e}")  # Log the error for debugging
        finally:
            connection.close()

    # Render the checkout page with package, insurance, and total price
    return render_template(
        'checkout.html',
        package=package,
        insurance=insurance,
        total_price=total_price
    )

@app.route('/resorts')
def resorts():
    # Get a database connection
    connection = get_db_connection()
    try:
        with connection.cursor() as cursor:
            # Query to join resort and manager tables
            cursor.execute("""
                SELECT 
                    resort.resort_id, 
                    resort.address, 
                    resort.email AS resort_email, 
                    resort.website, 
                    resort.rating, 
                    manager.name AS manager_name, 
                    manager.email AS manager_email, 
                    manager.phone AS manager_phone
                FROM resort
                INNER JOIN manager ON resort.manager_id = manager.manager_id
            """)
            # Fetch all rows from the query
            resorts = cursor.fetchall()
    finally:
        connection.close()
    
    # Pass the resorts data to the 'resorts.html' template
    return render_template('resorts.html', resorts=resorts)
@app.route('/reservations', methods=['GET', 'POST'])
def reservations():
    reservation_details = None
    error_message = None
    customer_name = None  # To store the customer's name

    if request.method == 'POST':
        reservation_id = request.form.get('reservation_id')

        if not reservation_id:
            error_message = "Please enter a reservation ID."
        else:
            try:
                # Get a database connection
                connection = get_db_connection()
                with connection.cursor() as cursor:
                    # Execute the SQL query to fetch reservation details and customer name
                    cursor.execute("""
                        SELECT 
                            r.reservation_id,
                            r.total_price,
                            a.name AS agent_name,
                            a.email AS agent_email,
                            a.phone AS agent_phone,
                            p.destination AS package_destination,
                            p.duration AS package_duration,
                            p.price AS package_price,
                            res.address AS resort_address,
                            res.email AS resort_email,
                            res.website AS resort_website,
                            res.rating AS resort_rating,
                            c.name AS customer_name  -- Fetch customer's name
                        FROM reservation r
                        INNER JOIN agent a ON r.agentid = a.agent_id
                        INNER JOIN package p ON r.packageid = p.package_id
                        INNER JOIN resort res ON p.resort_id = res.resort_id
                        INNER JOIN customer c ON r.customerid = c.customer_id  -- Join customer table
                        WHERE r.reservation_id = %s;
                    """, (reservation_id,))
                    
                    reservation_details = cursor.fetchone()

                    # If reservation is found, extract the customer's name
                    if reservation_details:
                        customer_name = reservation_details[-1]  # Customer name is the last column in the SELECT query
                    else:
                        error_message = f"No reservation found with ID {reservation_id}."
            except Exception as e:
                error_message = "An error occurred while fetching the reservation."
                print(f"Error: {e}")
            finally:
                connection.close()

    return render_template(
        'reservation.html',
        reservation_details=reservation_details,
        error_message=error_message,
        customer_name=customer_name  # Pass the customer's name to the template
    )
if __name__ == "__main__":
    app.run(debug=True)