-- MySQL dump 10.13  Distrib 8.0.40, for macos14 (arm64)
--
-- Host: 127.0.0.1    Database: onlinetravelagent
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agent`
--

DROP TABLE IF EXISTS `agent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent` (
  `agent_id` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  PRIMARY KEY (`agent_id`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `phone_UNIQUE` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent`
--

LOCK TABLES `agent` WRITE;
/*!40000 ALTER TABLE `agent` DISABLE KEYS */;
INSERT INTO `agent` VALUES (1001,'Sophie Lee','slee@example.com','555123567'),(1002,'James Smith','jsmith@example.com','555987654'),(1003,'Olivia Brown','obrown@example.com','555456789'),(1004,'Liam Kahn','lkahn@exapmle.com','555321432');
/*!40000 ALTER TABLE `agent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `customer_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `credit_card` varchar(15) NOT NULL,
  `agent_id` int DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `phone_UNIQUE` (`phone`),
  UNIQUE KEY `credit_card_UNIQUE` (`credit_card`),
  KEY `agent_id_idx` (`agent_id`),
  CONSTRAINT `agent_id` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`agent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insurance`
--

DROP TABLE IF EXISTS `insurance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insurance` (
  `insurance_id` int NOT NULL,
  `type` varchar(45) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`insurance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insurance`
--

LOCK TABLES `insurance` WRITE;
/*!40000 ALTER TABLE `insurance` DISABLE KEYS */;
INSERT INTO `insurance` VALUES (111,'No Insurance Coverage',0.00),(222,'Partial Insurance Coverage',180.00),(333,'Full Insurance Coverage',300.00);
/*!40000 ALTER TABLE `insurance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manager`
--

DROP TABLE IF EXISTS `manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `manager` (
  `manager_id` int NOT NULL,
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  PRIMARY KEY (`manager_id`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `phone_UNIQUE` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manager`
--

LOCK TABLES `manager` WRITE;
/*!40000 ALTER TABLE `manager` DISABLE KEYS */;
INSERT INTO `manager` VALUES (1111,'Avery Dubois','adubois.paris@example.com','555789123'),(2222,'Maya Rivera','mrivera.cancun@example.com','555456789'),(3333,'Theo Papadakis','tpapadakis.santorini@example.com','555123987'),(4444,'Michael Johnson','mjohnson.bahamas@example.com','555321654');
/*!40000 ALTER TABLE `manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package`
--

DROP TABLE IF EXISTS `package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `package` (
  `package_id` int NOT NULL,
  `destination` varchar(50) NOT NULL,
  `duration` int NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `resort_id` int NOT NULL,
  `insurance_id` int DEFAULT NULL,
  PRIMARY KEY (`package_id`),
  KEY `resort_id_idx` (`resort_id`),
  KEY `insurance_id_idx` (`insurance_id`),
  CONSTRAINT `insurance_id` FOREIGN KEY (`insurance_id`) REFERENCES `insurance` (`insurance_id`),
  CONSTRAINT `resort_id` FOREIGN KEY (`resort_id`) REFERENCES `resort` (`resort_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package`
--

LOCK TABLES `package` WRITE;
/*!40000 ALTER TABLE `package` DISABLE KEYS */;
INSERT INTO `package` VALUES (3001,'Paris 3-Day Premium',3,2200.00,101010,NULL),(3002,'Paris 3-Day Budget',3,1800.00,101010,NULL),(3003,'Cancun 3-Day Premium',3,1800.00,202020,NULL),(3004,'Cancun 3-Day Budget',3,1500.00,202020,NULL),(3005,'Santorini 3-Day Premium',3,2700.00,303030,NULL),(3006,'Santorini 3-Day Budget',3,2200.00,303030,NULL),(3007,'Bahamas 3-Day Premium',3,2300.00,404040,NULL),(3008,'Bahamas 3-Day Budget',3,1900.00,404040,NULL),(5001,'Paris 5-Day Premium',5,3100.00,101010,NULL),(5002,'Paris 5-Day Budget',5,2800.00,101010,NULL),(5003,'Cancun 5-Day Premium',5,2600.00,202020,NULL),(5004,'Cancun 5-Day Budget',5,2200.00,202020,NULL),(5005,'Santorini 5-Day Premium',5,3400.00,303030,NULL),(5006,'Santorini 5-Day Budget',5,3000.00,303030,NULL),(5007,'Bahamas 5-Day Premium',5,3100.00,404040,NULL),(5008,'Bahamas 5-Day Budget',5,2800.00,404040,NULL),(7001,'Paris 7-Day Premium',7,4000.00,101010,NULL),(7002,'Paris 7-Day Budget',7,3300.00,101010,NULL),(7003,'Cancun 7-Day Premium',7,3300.00,202020,NULL),(7004,'Cancun 7-Day Budget',7,2900.00,202020,NULL),(7005,'Santorini 7-Day Premium',7,4500.00,303030,NULL),(7006,'Santorini 7-Day Budget',7,4100.00,303030,NULL),(7007,'Bahamas 7-Day Premium',7,3600.00,404040,NULL),(7008,'Bahamas 7-Day Budget',7,3300.00,404040,NULL);
/*!40000 ALTER TABLE `package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservation` (
  `reservation_id` int NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `customerid` int NOT NULL,
  `agentid` int NOT NULL,
  `packageid` int NOT NULL,
  PRIMARY KEY (`reservation_id`),
  KEY `customerid_idx` (`customerid`),
  KEY `agentid_idx` (`agentid`),
  KEY `packageid_idx` (`packageid`),
  CONSTRAINT `agentid` FOREIGN KEY (`agentid`) REFERENCES `agent` (`agent_id`),
  CONSTRAINT `customerid` FOREIGN KEY (`customerid`) REFERENCES `customer` (`customer_id`),
  CONSTRAINT `packageid` FOREIGN KEY (`packageid`) REFERENCES `package` (`package_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resort`
--

DROP TABLE IF EXISTS `resort`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resort` (
  `resort_id` int NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(45) NOT NULL,
  `website` varchar(50) NOT NULL,
  `rating` int NOT NULL,
  `manager_id` int NOT NULL,
  PRIMARY KEY (`resort_id`),
  KEY `manager_id_idx` (`manager_id`),
  CONSTRAINT `manager_id` FOREIGN KEY (`manager_id`) REFERENCES `manager` (`manager_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resort`
--

LOCK TABLES `resort` WRITE;
/*!40000 ALTER TABLE `resort` DISABLE KEYS */;
INSERT INTO `resort` VALUES (101010,'15 Rue de Rivoli, Paris, France','loveparisresort@example.com','www.loveinparis.fr',5,1111),(202020,'Av. Kukulcán, Cancun, Mexico','lovecancunresort@example.com','www.loveincancun.com',5,2222),(303030,'Oia Village, Santorini, Greece','lovesantoriniresort@example.com','www.loveinsantorini.gr',5,3333),(404040,'Cable Beach, Nassau, Bahamas','lovebahamasresort@example.com','www.loveinbahamas.com',5,4444);
/*!40000 ALTER TABLE `resort` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-04 18:52:43
